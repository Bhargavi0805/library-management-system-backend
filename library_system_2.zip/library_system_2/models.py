from sqlalchemy import Column, Integer, String, Date, ForeignKey, create_engine
from sqlalchemy.orm import relationship, sessionmaker
from database import Base, engine

# Create the tables in the database
Base.metadata.create_all(bind=engine)




DATABASE_URL = "sqlite:///./library-system/sqlite/library.db"  # Adjust the path if necessary

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)



# User Model
class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True)
    password = Column(String)

    borrow_requests = relationship("BorrowRequest", back_populates="user")

# Book Model
class Book(Base):
    __tablename__ = "books"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, index=True)
    author = Column(String)
    available = Column(Integer, default=1)

    borrow_requests = relationship("BorrowRequest", back_populates="book")

# BorrowRequest Model
class BorrowRequest(Base):
    __tablename__ = "borrow_requests"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    book_id = Column(Integer, ForeignKey("books.id"))
    borrow_date = Column(Date)
    return_date = Column(Date)
    status = Column(String, default="Pending")  # Pending, Approved, Denied

    user = relationship("User", back_populates="borrow_requests")
    book = relationship("Book", back_populates="borrow_requests")

from database import engine, Base
from models import Book, User, BorrowRequest  # Import your models

# Create the tables in the database
Base.metadata.create_all(bind=engine)

