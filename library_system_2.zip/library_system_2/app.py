from fastapi import FastAPI
from routes import librarian_routes, user_routes  # Make sure the routes are imported

app = FastAPI()

# Include routes in the app
app.include_router(librarian_routes.router, prefix="/librarian", tags=["Librarian"])
app.include_router(user_routes.router, prefix="/user", tags=["User"])

@app.get("/")
def read_root():
    return {"message": "Welcome to the Library Management System!"}
