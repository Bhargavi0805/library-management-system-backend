from sqlalchemy.orm import Session
from models import User
from database import SessionLocal  # Assuming your session setup is in database.py

# Create a session
db = SessionLocal()

# Create a new user
new_user = User(name="Jane Doe", email="jane@example.com", password="securepassword")
db.add(new_user)  # Add the new user to the session
db.commit()  # Commit the transaction to save the user to the database
db.refresh(new_user)  # Refresh the object to get the latest data (e.g., auto-generated ID)

print(f"User {new_user.name} added successfully!")
