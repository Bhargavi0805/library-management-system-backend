import sqlite3

# Connect to the database
conn = sqlite3.connect("library.db")
cursor = conn.cursor()

# List all tables
cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
tables = cursor.fetchall()
print("Tables in the database:", tables)

# Check the schema of each table
for table_name in tables:
    print(f"\nSchema for table {table_name[0]}:")
    cursor.execute(f"PRAGMA table_info({table_name[0]});")
    schema = cursor.fetchall()
    for column in schema:
        print(column)

conn.close()
